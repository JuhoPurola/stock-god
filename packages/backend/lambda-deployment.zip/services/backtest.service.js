/**
 * Backtest Service - Simulates strategy performance on historical data
 */
import { logger } from '../utils/logger.js';
import { SignalType, OrderSide } from '@stock-picker/shared';
import { query } from '../config/database.js';
import { MomentumStrategy } from '@stock-picker/algorithm-engine';
/**
 * Backtest Engine
 */
export class BacktestService {
    /**
     * Run a backtest for a strategy
     */
    async runBacktest(backtestId, config, strategyConfig) {
        logger.info('Starting backtest', {
            backtestId,
            startDate: config.startDate,
            endDate: config.endDate,
        });
        try {
            // Initialize strategy
            const strategy = new MomentumStrategy(strategyConfig);
            // Initialize portfolio state
            const portfolioState = {
                cash: config.initialCash,
                positions: new Map(),
                totalValue: config.initialCash,
                dailyReturns: [],
                trades: [],
            };
            // Load historical price data
            const priceData = await this.loadHistoricalPrices(strategyConfig.stockUniverse, config.startDate, config.endDate);
            // Get trading days (sorted dates)
            const tradingDays = this.getTradingDays(priceData);
            const snapshots = [];
            logger.info('Loaded price data', {
                symbols: strategyConfig.stockUniverse.length,
                tradingDays: tradingDays.length,
                dateRange: tradingDays.length > 0 ? `${tradingDays[0]} to ${tradingDays[tradingDays.length - 1]}` : 'none',
            });
            // Log price data availability for each symbol
            for (const [symbol, prices] of priceData.entries()) {
                logger.info(`Price data for ${symbol}:`, {
                    dataPoints: prices.size,
                    sample: prices.size > 0 ? `${Array.from(prices.keys())[0]} = $${Array.from(prices.values())[0]}` : 'no data',
                });
            }
            // Iterate through each trading day
            for (const date of tradingDays) {
                // Update position prices with current day's prices
                this.updatePositionPrices(portfolioState, priceData, date);
                // Generate signals from strategy
                const signals = await this.generateSignals(strategy, strategyConfig, priceData, date, tradingDays);
                // Log signals on first few days for debugging
                if (tradingDays.indexOf(date) < 5) {
                    logger.info(`Signals generated on ${date}:`, {
                        totalSignals: signals.length,
                        signals: signals.map(s => ({
                            symbol: s.symbol,
                            type: s.type,
                            strength: s.strength,
                            factors: s.factorScores?.map(f => ({
                                name: f.factorName,
                                score: f.score,
                                confidence: f.confidence
                            }))
                        }))
                    });
                }
                // Execute trades based on signals
                for (const signal of signals) {
                    await this.executeBacktestTrade(backtestId, portfolioState, signal, priceData, date, config);
                }
                // Calculate daily snapshot
                const snapshot = this.calculateSnapshot(portfolioState, date);
                snapshots.push(snapshot);
            }
            // Calculate final performance metrics
            const performance = this.calculatePerformanceMetrics(snapshots, portfolioState, config.initialCash);
            logger.info('Backtest completed', {
                backtestId,
                totalTrades: portfolioState.trades.length,
                finalValue: portfolioState.totalValue,
            });
            return performance;
        }
        catch (error) {
            logger.error('Backtest failed', { backtestId, error });
            throw error;
        }
    }
    /**
     * Load historical price data for symbols
     */
    async loadHistoricalPrices(symbols, startDate, endDate) {
        const priceData = new Map();
        for (const symbol of symbols) {
            const result = await query(`
        SELECT timestamp, close
        FROM stock_prices
        WHERE symbol = $1
          AND timestamp >= $2
          AND timestamp <= $3
        ORDER BY timestamp ASC
      `, [symbol, startDate, endDate]);
            const symbolPrices = new Map();
            for (const row of result.rows) {
                symbolPrices.set(row.timestamp.toISOString().split('T')[0], parseFloat(row.close));
            }
            priceData.set(symbol, symbolPrices);
        }
        return priceData;
    }
    /**
     * Get sorted list of trading days
     */
    getTradingDays(priceData) {
        const datesSet = new Set();
        // Collect all unique dates from all symbols
        for (const symbolPrices of priceData.values()) {
            for (const date of symbolPrices.keys()) {
                datesSet.add(date);
            }
        }
        // Sort dates chronologically
        return Array.from(datesSet).sort();
    }
    /**
     * Update position prices with current market prices
     */
    updatePositionPrices(portfolioState, priceData, date) {
        let positionsValue = 0;
        for (const [symbol, position] of portfolioState.positions) {
            const symbolPrices = priceData.get(symbol);
            if (symbolPrices) {
                const currentPrice = symbolPrices.get(date);
                if (currentPrice) {
                    position.currentPrice = currentPrice;
                    position.marketValue = position.quantity * currentPrice;
                    position.unrealizedPnL = position.marketValue - position.costBasis;
                    positionsValue += position.marketValue;
                }
            }
        }
        portfolioState.totalValue = portfolioState.cash + positionsValue;
    }
    /**
     * Generate trading signals from strategy
     */
    async generateSignals(strategy, strategyConfig, priceData, currentDate, allDates) {
        // Create context provider that builds evaluation context for each symbol
        const contextProvider = async (symbol) => {
            const symbolPrices = priceData.get(symbol);
            if (!symbolPrices) {
                throw new Error(`No price data for ${symbol}`);
            }
            const currentPrice = symbolPrices.get(currentDate);
            if (!currentPrice) {
                throw new Error(`No price data for ${symbol} on ${currentDate}`);
            }
            // Get historical prices up to current date (for lookback periods)
            const currentDateIndex = allDates.indexOf(currentDate);
            const lookbackDates = allDates.slice(Math.max(0, currentDateIndex - 100), currentDateIndex + 1);
            const historicalPrices = lookbackDates
                .map((date) => {
                const price = symbolPrices.get(date);
                if (!price)
                    return null;
                return {
                    symbol,
                    timestamp: new Date(date),
                    open: price,
                    high: price * 1.02, // Approximate (we only have close prices)
                    low: price * 0.98,
                    close: price,
                    volume: 1000000, // Placeholder
                };
            })
                .filter((bar) => bar !== null);
            return {
                symbol,
                timestamp: new Date(currentDate),
                currentPrice,
                historicalPrices,
                // Technical indicators will be calculated by factors from historicalPrices
                technicalIndicators: {},
            };
        };
        // Generate signals using strategy
        const signals = await strategy.generateSignals(strategyConfig.stockUniverse, contextProvider);
        // Filter out HOLD signals for backtesting
        return signals.filter((s) => s.type !== SignalType.HOLD);
    }
    /**
     * Execute a simulated trade in the backtest
     */
    async executeBacktestTrade(backtestId, portfolioState, signal, priceData, date, config) {
        const symbolPrices = priceData.get(signal.symbol);
        if (!symbolPrices)
            return;
        const currentPrice = symbolPrices.get(date);
        if (!currentPrice)
            return;
        // Apply slippage
        const executionPrice = signal.type === SignalType.BUY
            ? currentPrice * (1 + config.slippage)
            : currentPrice * (1 - config.slippage);
        // Calculate quantity (for now, use fixed amount)
        const tradeAmount = portfolioState.cash * 0.1; // 10% of cash
        const quantity = Math.floor(tradeAmount / executionPrice);
        if (quantity === 0)
            return;
        const side = signal.type === SignalType.BUY ? OrderSide.BUY : OrderSide.SELL;
        const amount = quantity * executionPrice + config.commission;
        if (side === OrderSide.BUY) {
            if (amount > portfolioState.cash)
                return; // Not enough cash
            // Update cash
            portfolioState.cash -= amount;
            // Update or create position
            const existingPosition = portfolioState.positions.get(signal.symbol);
            if (existingPosition) {
                const newTotalCost = existingPosition.costBasis + quantity * executionPrice;
                const newTotalQuantity = existingPosition.quantity + quantity;
                existingPosition.quantity = newTotalQuantity;
                existingPosition.averagePrice = newTotalCost / newTotalQuantity;
                existingPosition.costBasis = newTotalCost;
                existingPosition.currentPrice = executionPrice;
                existingPosition.marketValue = newTotalQuantity * executionPrice;
                existingPosition.unrealizedPnL =
                    existingPosition.marketValue - existingPosition.costBasis;
            }
            else {
                portfolioState.positions.set(signal.symbol, {
                    symbol: signal.symbol,
                    quantity,
                    averagePrice: executionPrice,
                    currentPrice: executionPrice,
                    costBasis: quantity * executionPrice,
                    marketValue: quantity * executionPrice,
                    unrealizedPnL: 0,
                });
            }
            // Record trade
            await this.recordBacktestTrade(backtestId, date, signal, side, quantity, executionPrice, amount, null);
        }
        else {
            // Sell
            const position = portfolioState.positions.get(signal.symbol);
            if (!position || position.quantity < quantity)
                return; // Not enough shares
            const pnl = (executionPrice - position.averagePrice) * quantity - config.commission;
            // Update cash
            portfolioState.cash += quantity * executionPrice - config.commission;
            // Update position
            position.quantity -= quantity;
            position.marketValue = position.quantity * executionPrice;
            position.costBasis -= quantity * position.averagePrice;
            position.unrealizedPnL = position.marketValue - position.costBasis;
            if (position.quantity === 0) {
                portfolioState.positions.delete(signal.symbol);
            }
            // Record trade
            await this.recordBacktestTrade(backtestId, date, signal, side, quantity, executionPrice, amount, pnl);
        }
    }
    /**
     * Record backtest trade in database
     */
    async recordBacktestTrade(backtestId, date, signal, side, quantity, price, amount, pnl) {
        await query(`
      INSERT INTO backtest_trades (
        backtest_id, timestamp, symbol, side, quantity, price, amount, signal, pnl
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
    `, [
            backtestId,
            date,
            signal.symbol,
            side,
            quantity,
            price,
            amount,
            JSON.stringify(signal),
            pnl,
        ]);
    }
    /**
     * Calculate daily snapshot
     */
    calculateSnapshot(portfolioState, date) {
        let positionsValue = 0;
        for (const position of portfolioState.positions.values()) {
            positionsValue += position.marketValue;
        }
        const totalValue = portfolioState.cash + positionsValue;
        const previousValue = portfolioState.dailyReturns.length > 0
            ? portfolioState.dailyReturns[portfolioState.dailyReturns.length - 1] ?? totalValue
            : totalValue;
        const dailyReturn = totalValue - previousValue;
        portfolioState.dailyReturns.push(totalValue);
        const firstValue = portfolioState.dailyReturns[0] ?? totalValue;
        return {
            date: new Date(date),
            cash: portfolioState.cash,
            positionsValue,
            totalValue,
            dailyReturn,
            cumulativeReturn: totalValue - firstValue,
        };
    }
    /**
     * Calculate performance metrics
     */
    calculatePerformanceMetrics(snapshots, portfolioState, initialCash) {
        if (snapshots.length === 0) {
            return {
                totalReturn: 0,
                totalReturnPercent: 0,
                sharpeRatio: 0,
                maxDrawdown: 0,
                winRate: 0,
                profitFactor: 0,
                totalTrades: 0,
                avgTradeReturn: 0,
            };
        }
        const finalSnapshot = snapshots[snapshots.length - 1];
        const firstSnapshot = snapshots[0];
        if (!finalSnapshot || !firstSnapshot) {
            throw new Error('Snapshots array is invalid');
        }
        const finalValue = finalSnapshot.totalValue;
        const totalReturn = finalValue - initialCash;
        const totalReturnPercent = (totalReturn / initialCash) * 100;
        // Calculate max drawdown
        let maxDrawdown = 0;
        let peak = firstSnapshot.totalValue;
        for (const snapshot of snapshots) {
            if (snapshot.totalValue > peak) {
                peak = snapshot.totalValue;
            }
            const drawdown = ((peak - snapshot.totalValue) / peak) * 100;
            if (drawdown > maxDrawdown) {
                maxDrawdown = drawdown;
            }
        }
        // Calculate Sharpe ratio (simplified - assumes daily returns)
        const returns = snapshots.map((s) => s.dailyReturn);
        const avgReturn = returns.reduce((sum, r) => sum + r, 0) / returns.length;
        const stdDev = Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) /
            returns.length);
        const sharpeRatio = stdDev > 0 ? (avgReturn / stdDev) * Math.sqrt(252) : 0;
        // Win rate and profit factor from trades
        const totalTrades = portfolioState.trades.length;
        const tradesWithPnL = portfolioState.trades.filter((t) => t.pnl !== undefined && t.pnl !== null);
        let winningTrades = 0;
        let losingTrades = 0;
        let totalWins = 0;
        let totalLosses = 0;
        for (const trade of tradesWithPnL) {
            if (trade.pnl > 0) {
                winningTrades++;
                totalWins += trade.pnl;
            }
            else if (trade.pnl < 0) {
                losingTrades++;
                totalLosses += Math.abs(trade.pnl);
            }
        }
        const winRate = tradesWithPnL.length > 0 ? (winningTrades / tradesWithPnL.length) * 100 : 0;
        const profitFactor = totalLosses > 0 ? totalWins / totalLosses : totalWins > 0 ? Infinity : 0;
        const averageWin = winningTrades > 0 ? totalWins / winningTrades : 0;
        const averageLoss = losingTrades > 0 ? totalLosses / losingTrades : 0;
        return {
            totalReturn,
            totalReturnPercent,
            sharpeRatio,
            maxDrawdown,
            winRate,
            profitFactor,
            totalTrades,
            winningTrades,
            losingTrades,
            averageWin,
            averageLoss,
            avgTradeReturn: totalTrades > 0 ? totalReturn / totalTrades : 0,
        };
    }
}
export const backtestService = new BacktestService();
//# sourceMappingURL=backtest.service.js.map