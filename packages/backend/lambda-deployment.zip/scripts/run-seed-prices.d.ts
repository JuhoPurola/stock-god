#!/usr/bin/env node
/**
 * Script to run seed-prices.sql directly against the database
 */
export {};
//# sourceMappingURL=run-seed-prices.d.ts.map