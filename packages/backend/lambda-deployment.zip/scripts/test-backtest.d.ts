/**
 * Test script to run a backtest and verify the integration
 */
declare function runTestBacktest(): Promise<import("@stock-picker/shared").StrategyPerformance>;
export { runTestBacktest };
//# sourceMappingURL=test-backtest.d.ts.map