#!/usr/bin/env node
/**
 * Script to populate stocks table with common trading symbols
 */
export {};
//# sourceMappingURL=populate-stocks.d.ts.map