/**
 * Setup test data for backtest testing
 */
declare function setupTestData(): Promise<void>;
export { setupTestData };
//# sourceMappingURL=setup-test-data.d.ts.map